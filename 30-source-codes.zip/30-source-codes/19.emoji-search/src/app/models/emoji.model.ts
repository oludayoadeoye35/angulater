export interface Emoji {
  symbol: string;
  name: string;
  category: string;
}
