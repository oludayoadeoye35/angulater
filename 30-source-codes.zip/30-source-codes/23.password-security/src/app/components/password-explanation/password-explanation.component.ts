import { Component } from '@angular/core';

@Component({
  selector: 'app-password-explanation',
  imports: [],
  templateUrl: './password-explanation.component.html',
  styleUrl: './password-explanation.component.scss'
})
export class PasswordExplanationComponent {

}
