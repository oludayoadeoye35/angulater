export const environment = {
  production: false,
  weatherApiKey: '715f0a4367c1cdea16269f8b0e5b20e5',
};
