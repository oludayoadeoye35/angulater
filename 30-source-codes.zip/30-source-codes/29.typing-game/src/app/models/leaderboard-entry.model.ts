export interface LeaderboardEntry {
  username: string;
  cleanSpeed: number;
  rawSpeed: number;
  accuracy: number;
}
